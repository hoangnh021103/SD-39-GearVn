package spring.api.apistart.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import spring.api.apistart.entity.DonHangKhachVangLai;

public interface DonHangKhachVangLaiRepository extends JpaRepository<DonHangKhachVangLai, Integer> {
}