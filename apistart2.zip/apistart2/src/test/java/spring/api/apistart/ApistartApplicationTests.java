package spring.api.apistart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApistartApplicationTests {

	@Test
	void contextLoads() {
	}

}
